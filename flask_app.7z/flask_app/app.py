
# Importing Libraries and Modules

from flask import Flask, request, render_template, jsonify    # Import Flask as main module, Request to handle HTTP Requests, Render_Template to Render HTML Pages
from werkzeug.utils import secure_filename                    # Import Secure_Filename Utility from Werkzeug to prevent file name attacks
import os                                                     # Import OS to interact with the operating systems file system
import csv                                                    # Import CSV to make handling the submitted csv files directly possible

#Initializing Flask Application
app = Flask(__name__)                                             # Initializes Flask application

#Security Settings
app.secret_key = 'F82E44F2E6F29FEEDB747A5BDC3BD'                  # Key Used by flask for cryptographic operations such as signing session cookies
ALLOWED_EXTENSIONS = {'csv'}                                      # List of all allowed file extenstions, only CSV files are permited, prevents unusable or harmfull file types from being submitted

#Upload Folder Configuration,  The Upload folder is the location where data submitted by users gets saved, with all the changes made to it based on results from the submission form
UPLOAD_FOLDER = 'uploads'                                         # Path where uploaded data will be stored, in a folder called "uploads" in the base of the directory
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER                       # Create a parameter where the upload folder defined above can be accessed through
os.makedirs(UPLOAD_FOLDER, exist_ok=True)                         # Creates the Upload Directory if it doesn't exsist

# Submission Log File Configuraetion, The Submission Log is used to track how many submissions have been made and to name the submissions accordingly to organize files during development
SUBMISSION_LOG = 'submission_log.csv'                             # Path where submission number log is saved
if not os.path.exists(SUBMISSION_LOG):                            # If the Submission log does not exsist it creates it
    with open(SUBMISSION_LOG, 'w', newline='') as log_file:       # Use the CSV writer to write submission number header at the top of the newly created CSV file
        writer = csv.writer(log_file)
        writer.writerow(['submission_number'])

# Check if a file extension is allowed
def allowed_file(filename):                                       # Create a function called allowed_file, the function will return true or false if the extension (After the last period) is on the "ALLOWED_EXTENSIONS" list
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Get the next submission number
def get_next_submission_number():                                 # If the submission_number.csv file does not exsist, or it is empty, it will call it submission '1'
    if not os.path.exists(SUBMISSION_LOG) or os.path.getsize(SUBMISSION_LOG) == 0:
        return 1

    with open(SUBMISSION_LOG, 'r') as log_file:                   # Open the CSV in reader mode
        reader = csv.reader(log_file)                             # Create a CSV reader object
        next(reader)                                              # Skip the header row
        last_row = list(reader)                                   # Read the rest of the rows into a list
        
        if not last_row:                                          # Check if there was anything below the header
            return 1                                              # If there is nothing below the header return '1'

        last_submission_number = int(last_row[-1][0])             # Make "last_submission_number" equal to the value of the last row
    return last_submission_number + 1                             # Return the value of the last row plus 1 to become the new submission number

# Configure URLs and page responses
@app.route('/')                                                   # URL for the home page
def home():                                                       # Function that handles requests to the home page
    return render_template('index.html')                          # When the home page is accessed, render this file

@app.route('/fileupload')                                         # URL for the page where files are uploaded
def upload_page():                                                # Function that handles requests to the upload page
    return render_template('fileUpload.html')                     # When the file upload page is accessed, render this file



@app.route('/upload', methods=['POST'])                           # URL to handle file uploads over POST requests
def upload_file():                                                # Function to handle requests to upload page
    try:
        if 'file' not in request.files:                           # Returns error if no file part is in the request
            return jsonify({'error': 'No file part'}), 400
        file = request.files['file']
        if file.filename == '':                                   # Return error if the file name is not in the request
            return jsonify({'error': 'No selected file'}), 400

        if not allowed_file(file.filename):                       # Return error if the file name does not pass the file extension check
            return jsonify({'error': 'File type not allowed'}), 400
        

        original_filename = secure_filename(file.filename)        # Change the file name name to remove any harmfull characters   

        submission_number = get_next_submission_number()          # Get the Submission number

        file_path = os.path.join(app.config['UPLOAD_FOLDER'], f'submission{submission_number}.csv')
        file.save(file_path)                                      # Save the uploaded file to a new file path created with the submission number

        zip_code = request.form.get('zip_code')                   # Gets the Zip Code from the form data
        cloud_cover = request.form.get('cloud_cover')             # Gets the Cloud Cover from the form data

        # Assign the first row as headers if possible and any remaining rows as rows, this is so that the heades can be appended regardless of the data in any other rows
        with open(file_path, 'r', newline='') as f:               # Opens the exsisting file in reader mode without creating a new line
            reader = csv.reader(f)                                # Creates a CSV reader file to read the file
            data = list(reader)                                   # Converts the file data into a list of rows

        if data:                                                  # Checks if there is any data to read in the CSV file
            headers = data[0]                                     # Of there is data define the 0'th row as headers
            rows = data[1:]                                       # Any Remaining rows in the CSV file are assigned to rows
        else:
            headers = []                                          # If the list is empty initialize the list of headers empty
            rows = []                                             # If the list is empty initialize the list of rows empty

        # Ensure headers include new headers for form results
        if 'ZipCode' not in headers:                              # If there is not a header called "ZipCode"
            headers.append('ZipCode')                             # Make a new header called "ZipCode"
        if 'CloudCover' not in headers:                           # If there is not a header called "CloudCover"
            headers.append('CloudCover')                          # Make a new header called "CloudCover"

        # Update rows to include form results in benieth the correct headers
        updated_data = []                                         # Initialize an empty list to store updated rows
        for row in rows:                                          # Move over each row from the original data
            while len(row) < len(headers):                        # Ensure row length matches headers length
                row.append('')                                    # If the row length is less then the header length, add empty strings untill they match
            row[headers.index('ZipCode')] = zip_code              # In the same column of the row as the column of the header, append the form result
            row[headers.index('CloudCover')] = cloud_cover        # In the same column of the row as the column of the header, append the form result
            
            if any(cell for cell in row if cell and headers[row.index(cell)] not in ['ZipCode', 'CloudCover']):
                updated_data.append(row)                          # Check if the row has any values besides the correct values for the form result columns, if it passes, add it to the new list

        with open(file_path, 'w', newline='') as f:               # Open the CSV in write mode without creating a new line
            writer = csv.writer(f)                                # Create a CSV writer object to write to the file
            writer.writerow(headers)                              # Writes the header row to the new CSV file
            writer.writerows(updated_data)                        # Writes the data from the new list to the new CSV file

        with open(SUBMISSION_LOG, 'a', newline='') as log_file:   # Open the submission log in append mode without creating a new line
            writer = csv.writer(log_file)                         # Create a CSV Writer object to write to the log file  
            writer.writerow([submission_number])                  # Writes the new submission number to the log file

        return jsonify({'message': 'File successfully uploaded and data saved', 'path': file_path}), 200
                                                                  # Converts to a JSON response with a message that says the file was successfully uploaded, and http code for successfull request

    except Exception as e:                                        # Convert to a JSON response with a message that says error and includes the http code 500 for internal server error
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':                                        # Ensure that the flask application only runs if it is executed directly
    app.run(debug=True)                                           # Start the Flask Server in debug mode for detailed error messages and automatically reloading it when part of the code changes
